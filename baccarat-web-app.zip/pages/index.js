import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

export default function BaccaratAnalyzer() {
  const [results, setResults] = useState([]);
  const [input, setInput] = useState("");

  const handleAddResult = () => {
    if (input === "P" || input === "B") {
      setResults([...results, input]);
      setInput("");
    }
  };

  const analyzePatterns = () => {
    return results.map((val, i) => {
      const prev1 = results[i - 1];
      const prev2 = results[i - 2];
      const prev3 = results[i - 3];

      if (val === prev1 && prev1 === prev2) return { index: i + 1, pattern: "ติดยาว" };
      if (val !== prev1 && prev1 === prev2 && prev2 !== prev3) return { index: i + 1, pattern: "ตัวตัด" };
      if (prev3 === val && prev2 !== val && prev1 === prev2) return { index: i + 1, pattern: "ปิงปอง" };
      return { index: i + 1, pattern: "-" };
    });
  };

  const predicted = () => {
    const len = results.length;
    if (len >= 3 && results[len - 1] === results[len - 2] && results[len - 2] === results[len - 3]) {
      return results[len - 1];
    } else if (len >= 2 && results[len - 1] !== results[len - 2]) {
      return results[len - 2];
    }
    return "?";
  };

  const stats = () => {
    const total = results.length;
    const p = results.filter(r => r === "P").length;
    const b = results.filter(r => r === "B").length;
    return [
      { name: "Player", value: (p / total) * 100 || 0 },
      { name: "Banker", value: (b / total) * 100 || 0 }
    ];
  };

  const patterns = analyzePatterns();

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold text-center">วิเคราะห์เค้าไพ่บาคาร่า</h1>

      <Card>
        <CardContent className="space-y-2 pt-4">
          <div className="flex gap-2">
            <Input value={input} onChange={e => setInput(e.target.value.toUpperCase())} placeholder="กรอก P หรือ B" />
            <Button onClick={handleAddResult}>เพิ่ม</Button>
          </div>
          <div className="text-sm text-muted-foreground">ผลลัพธ์: {results.join(", ")}</div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <h2 className="font-semibold">เค้าไพ่</h2>
          <ul className="text-sm list-disc pl-4">
            {patterns.map((p, i) => (
              <li key={i}>ตาที่ {p.index}: {p.pattern}</li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <h2 className="font-semibold">การทำนายผลถัดไป</h2>
          <p className="text-lg">{predicted()}</p>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-4">
          <h2 className="font-semibold">สถิติ</h2>
          <LineChart width={300} height={200} data={stats()}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="value" stroke="#8884d8" />
          </LineChart>
        </CardContent>
      </Card>
    </div>
  );
}
