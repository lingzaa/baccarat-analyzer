export function Input({ value, onChange, placeholder }) {
  return <input value={value} onChange={onChange} placeholder={placeholder} className="border rounded-xl px-3 py-2 w-full" />;
}
